# CMake generated Testfile for 
# Source directory: /tmp/opencode/libzip-1.11.3/src
# Build directory: /tmp/opencode/libzip-1.11.3/build-static/src
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
