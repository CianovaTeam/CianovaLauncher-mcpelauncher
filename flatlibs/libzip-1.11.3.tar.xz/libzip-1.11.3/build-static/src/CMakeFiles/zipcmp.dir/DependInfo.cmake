
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/opencode/libzip-1.11.3/src/diff_output.c" "src/CMakeFiles/zipcmp.dir/diff_output.c.o" "gcc" "src/CMakeFiles/zipcmp.dir/diff_output.c.o.d"
  "/tmp/opencode/libzip-1.11.3/src/zipcmp.c" "src/CMakeFiles/zipcmp.dir/zipcmp.c.o" "gcc" "src/CMakeFiles/zipcmp.dir/zipcmp.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
